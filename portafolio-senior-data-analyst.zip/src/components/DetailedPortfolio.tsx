import { useState } from 'react';
import { motion } from 'motion/react';
import { projectsDataList } from '../data';
import { Project } from '../types';
import { 
  BarChart3, 
  Database, 
  TrendingUp, 
  Brain, 
  LineChart as LineIcon, 
  Search, 
  CheckCircle2, 
  ChevronRight, 
  Layers, 
  Compass, 
  ShieldCheck, 
  ArrowLeft,
  Filter,
  DollarSign,
  Calendar,
  AlertCircle
} from 'lucide-react';

export default function DetailedPortfolio({ onBackToProfile }: { onBackToProfile: () => void }) {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedProject, setSelectedProject] = useState<Project>(projectsDataList[0]);
  const [searchTerm, setSearchTerm] = useState('');

  // S&OP Dashboard details
  const [sopVendorFilter, setSopVendorFilter] = useState('TODOS');
  const [sopZoneFilter, setSopZoneFilter] = useState('TODOS');

  // Suzuki Filter
  const [suzukiModel, setSuzukiModel] = useState('GIXXER-150');
  const [suzukiRegion, setSuzukiRegion] = useState('TODOS');

  const categories = [
    { id: 'all', name: 'Todos los Proyectos' },
    { id: 'finance', name: 'Riesgos & Finanzas' },
    { id: 'sales', name: 'Resultados S&OP' },
    { id: 'predictive', name: 'Predicción & Forecasting' },
    { id: 'market', name: 'Distribución & Mercado' }
  ];

  const filteredProjects = projectsDataList.filter(project => {
    const matchesCategory = selectedCategory === 'all' || project.category === selectedCategory;
    const matchesSearch = project.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          project.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          project.tags.some(t => t.toLowerCase().includes(searchTerm.toLowerCase()));
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans pb-20 selection:bg-brand-blue/30 selection:text-white">
      {/* Mini Breadcrumb/Header */}
      <div className="w-full max-w-6xl mx-auto px-4 md:px-8 pt-8">
        <button 
          onClick={onBackToProfile}
          className="group inline-flex items-center gap-2 text-xs font-mono text-slate-500 hover:text-brand-green transition-colors py-2 px-3 rounded-lg bg-slate-900/30 border border-slate-900 hover:border-slate-800"
        >
          <ArrowLeft className="w-3.5 h-3.5 group-hover:-translate-x-1 transition-transform" />
          <span>Volver al Perfil Principal</span>
        </button>
      </div>

      {/* Hero Header */}
      <section className="relative py-12 px-4 md:px-8 overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-brand-blue-glow rounded-full blur-[140px] pointer-events-none opacity-40" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-brand-green-glow rounded-full blur-[140px] pointer-events-none opacity-40" />

        <div className="max-w-6xl mx-auto relative z-10 text-left space-y-4">
          <div className="flex items-center gap-2 text-brand-green font-mono text-xs uppercase tracking-widest">
            <Compass className="w-4 h-4 animate-spin-slow" />
            <span>Portafolio Técnico de Datos</span>
          </div>
          <h1 className="text-4xl md:text-5xl font-bold font-display text-white tracking-tight">
            Casos Prácticos & Soluciones de Negocios
          </h1>
          <p className="text-slate-400 text-sm md:text-base max-w-3xl leading-relaxed">
            Explora las herramientas desarrolladas por <strong className="text-slate-200">Kleber Villalobos</strong> para automatizar el control regulatorio, proyectar ventas de vehículos y unificar KPIs estratégicos a través de modelos robustos en Python y Power BI.
          </p>
        </div>
      </section>

      {/* Interactive Main Body */}
      <section className="max-w-6xl mx-auto w-full px-4 md:px-8 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left Side: Project Navigator & Search */}
        <div className="lg:col-span-4 space-y-6">
          
          {/* Search and Category Filters */}
          <div className="p-5 rounded-2xl bg-slate-900/40 border border-slate-900 backdrop-blur-md space-y-4">
            <h3 className="text-xs font-mono uppercase tracking-widest text-slate-400 font-semibold flex items-center gap-2">
              <Filter className="w-3.5 h-3.5 text-brand-blue" />
              <span>Filtrar Portafolio</span>
            </h3>

            {/* Search Input */}
            <div className="relative">
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-500" />
              <input
                type="text"
                placeholder="Buscar por tag o palabra..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl py-2 pl-9 pr-4 text-xs font-mono text-slate-300 placeholder:text-slate-600 focus:outline-none focus:border-brand-blue transition-colors"
              />
            </div>

            {/* Category Buttons list */}
            <div className="space-y-1.5 pt-2">
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => {
                    setSelectedCategory(cat.id);
                    // Select first project matching new category
                    const matched = projectsDataList.find(p => cat.id === 'all' || p.category === cat.id);
                    if (matched) setSelectedProject(matched);
                  }}
                  className={`w-full text-left px-3.5 py-2.5 rounded-xl text-xs font-mono transition-all flex items-center justify-between border ${
                    selectedCategory === cat.id
                      ? 'bg-brand-blue/10 border-brand-blue/30 text-white font-semibold'
                      : 'bg-transparent border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900/50'
                  }`}
                >
                  <span>{cat.name}</span>
                  <ChevronRight className={`w-3.5 h-3.5 opacity-60 transform transition-transform ${selectedCategory === cat.id ? 'translate-x-0.5' : ''}`} />
                </button>
              ))}
            </div>
          </div>

          {/* List of matched projects */}
          <div className="space-y-3">
            <h4 className="text-xs font-mono uppercase tracking-widest text-slate-500 font-semibold pl-1">
              Resultados ({filteredProjects.length})
            </h4>

            {filteredProjects.length === 0 ? (
              <div className="p-8 text-center rounded-2xl bg-slate-900/20 border border-slate-900 font-mono text-xs text-slate-600">
                Ningún proyecto coincide con la búsqueda.
              </div>
            ) : (
              <div className="space-y-2 max-h-[420px] overflow-y-auto pr-1 scrollbar-thin">
                {filteredProjects.map((proj) => {
                  const isSelected = selectedProject.id === proj.id;
                  return (
                    <button
                      key={proj.id}
                      onClick={() => setSelectedProject(proj)}
                      className={`w-full text-left p-4 rounded-xl transition-all border ${
                        isSelected
                          ? 'bg-slate-900 border-slate-700/80 shadow-lg shadow-black/30'
                          : 'bg-slate-950/40 border-slate-900 hover:border-slate-800 hover:bg-slate-900/20'
                      }`}
                    >
                      <span className="text-[10px] font-mono text-brand-green uppercase tracking-widest block mb-1">
                        {proj.category === 'finance' ? 'Finanzas & Riesgos' : 
                         proj.category === 'sales' ? 'Control S&OP' : 
                         proj.category === 'predictive' ? 'Pronósticos / ML' : 'Distribución / Mercado'}
                      </span>
                      <h5 className="text-xs font-bold text-white font-display mb-1.5 line-clamp-1">
                        {proj.title}
                      </h5>
                      <p className="text-[11px] text-slate-400 line-clamp-2 leading-relaxed">
                        {proj.description}
                      </p>
                      <div className="flex flex-wrap gap-1 mt-2.5">
                        {proj.tags.slice(0, 3).map(tag => (
                          <span key={tag} className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-400">
                            {tag}
                          </span>
                        ))}
                        {proj.tags.length > 3 && (
                          <span className="text-[9px] font-mono text-slate-500 px-1 py-0.5">+{proj.tags.length - 3}</span>
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Right Side: Detailed Project Inspector (High-Fidelity UI Presentation) */}
        <div className="lg:col-span-8">
          <motion.div
            key={selectedProject.id}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            className="rounded-2xl bg-slate-950 border border-slate-850 shadow-2xl overflow-hidden flex flex-col"
          >
            {/* Window chrome header */}
            <div className="px-5 py-4 border-b border-slate-900 bg-slate-950/80 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-2.5 h-2.5 rounded-full bg-red-500/60" />
                <div className="w-2.5 h-2.5 rounded-full bg-yellow-500/60" />
                <div className="w-2.5 h-2.5 rounded-full bg-green-500/60" />
                <span className="text-[10px] font-mono text-slate-500 ml-2 tracking-wide">
                  visor_portafolio_proyectos.json
                </span>
              </div>
              <span className="px-2 py-0.5 rounded bg-brand-green/10 text-brand-green border border-brand-green/20 text-[9px] font-mono tracking-widest uppercase">
                {selectedProject.category}
              </span>
            </div>

            {/* Core Project Details */}
            <div className="p-6 md:p-8 space-y-6">
              
              <div className="space-y-2">
                <h2 className="text-2xl md:text-3xl font-bold font-display text-white tracking-tight">
                  {selectedProject.title}
                </h2>
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {selectedProject.tags.map(tag => (
                    <span key={tag} className="px-2 py-0.5 rounded-md bg-slate-900 border border-slate-800 text-xs font-mono text-slate-300">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>

              {/* Long Description */}
              <div className="space-y-3">
                <h4 className="text-xs font-mono uppercase tracking-widest text-slate-500">
                  Resumen de la Solución
                </h4>
                <p className="text-slate-300 text-sm leading-relaxed font-light">
                  {selectedProject.longDescription || selectedProject.description}
                </p>
              </div>

              {/* Custom High-Fidelity Interactive Layout (Simulating the PDF content directly!) */}
              <div className="border border-slate-900 rounded-2xl bg-slate-950 p-5 space-y-6 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-24 h-24 bg-brand-blue/5 rounded-full blur-2xl pointer-events-none" />
                
                <div className="flex items-center justify-between pb-3 border-b border-slate-900">
                  <span className="text-[11px] font-mono font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                    <Layers className="w-4 h-4 text-brand-green" />
                    Vista Interactiva Simplificada
                  </span>
                  <span className="text-[9px] font-mono text-slate-500">
                    *Muestra interactiva con fines demostrativos
                  </span>
                </div>

                {/* PROJECT 1 VIEW: Dashboard de Resultados S&OP */}
                {selectedProject.id === 'dashboard-resultados' && (
                  <div className="space-y-4 font-mono text-xs text-slate-300">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                      <div className="p-3 rounded-lg bg-slate-900 border border-slate-800/80">
                        <span className="text-[10px] text-slate-500 block">MAYO 2022</span>
                        <div className="text-lg font-bold text-white mt-1">103 <span className="text-[10px] font-normal text-slate-400">/ 357 u.</span></div>
                        <span className="text-[9px] text-brand-green">Unidades Vendidas</span>
                      </div>
                      <div className="p-3 rounded-lg bg-slate-900 border border-slate-800/80">
                        <span className="text-[10px] text-slate-500 block">FACTURACIÓN</span>
                        <div className="text-lg font-bold text-white mt-1">₡157.68M</div>
                        <span className="text-[9px] text-slate-400">Consolidado Mensual</span>
                      </div>
                      <div className="p-3 rounded-lg bg-slate-900 border border-slate-800/80">
                        <span className="text-[10px] text-slate-500 block">ZONA PREDOMINANTE</span>
                        <div className="text-lg font-bold text-white mt-1">GAM (64%)</div>
                        <span className="text-[9px] text-slate-400">Rural (36%)</span>
                      </div>
                    </div>

                    <div className="p-3.5 rounded-lg bg-slate-900/50 border border-slate-900 space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-white uppercase">Ranking de Vendedores</span>
                        <span className="text-[10px] text-slate-500">Unidades Netas</span>
                      </div>
                      <div className="space-y-1.5 text-[11px]">
                        <div className="flex justify-between items-center py-1 border-b border-slate-950">
                          <span className="text-slate-400">Moises Espinoza Castillo</span>
                          <span className="font-bold text-brand-green">12 u. (Top #1)</span>
                        </div>
                        <div className="flex justify-between items-center py-1 border-b border-slate-950">
                          <span className="text-slate-400">Almacen Mozel S.A.</span>
                          <span className="font-bold text-slate-200">8 u.</span>
                        </div>
                        <div className="flex justify-between items-center py-1">
                          <span className="text-slate-400">Nayubhet de los Angeles</span>
                          <span className="font-bold text-slate-200">8 u.</span>
                        </div>
                      </div>
                    </div>

                    <p className="text-[10px] text-slate-500 text-center italic">
                      *Los datos se presentan simulados y consolidados bajo políticas de estricta confidencialidad de la junta directiva.
                    </p>
                  </div>
                )}

                {/* PROJECT 2 VIEW: Torre de Control BCCR */}
                {selectedProject.id === 'torre-control' && (
                  <div className="space-y-4 font-mono text-xs text-slate-300">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      
                      {/* BCCR Live data extract */}
                      <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-3">
                        <span className="text-xs font-bold text-white uppercase tracking-wider block border-b border-slate-800 pb-2">
                          Extracción Webservice BCCR
                        </span>
                        <div className="space-y-2">
                          <div className="flex justify-between">
                            <span className="text-slate-500">Tasa Política Monetaria (TPM)</span>
                            <span className="text-white font-semibold">4.00%</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-500">Tasa Básica Pasiva (TBP)</span>
                            <span className="text-white font-semibold">3.99%</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-500">Tipo de Cambio Venta</span>
                            <span className="text-white font-semibold">₡512.14</span>
                          </div>
                        </div>
                        <div className="pt-1.5 flex items-center gap-1.5 text-[9px] text-brand-green">
                          <span className="w-1.5 h-1.5 bg-brand-green rounded-full animate-ping" />
                          <span>Actualizado automáticamente (Python API)</span>
                        </div>
                      </div>

                      {/* Internal Risk Matrix */}
                      <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-3">
                        <span className="text-xs font-bold text-white uppercase tracking-wider block border-b border-slate-800 pb-2">
                          Métricas Internas de Riesgo
                        </span>
                        <div className="space-y-2">
                          <div className="flex justify-between items-center">
                            <span className="text-slate-500">Mora Legal</span>
                            <span className="text-emerald-400 bg-emerald-950/30 px-1.5 py-0.5 rounded text-[10px] font-semibold">BAJO CONTROL</span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-slate-500">Mora &gt; 90 días</span>
                            <span className="text-emerald-400 bg-emerald-950/30 px-1.5 py-0.5 rounded text-[10px] font-semibold">DENTRO DE LÍMITES</span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-slate-500">Ratio de Liquidez (ICL)</span>
                            <span className="text-emerald-400 bg-emerald-950/30 px-1.5 py-0.5 rounded text-[10px] font-semibold">ÓPTIMO</span>
                          </div>
                        </div>
                        <span className="text-[9px] text-slate-500 block pt-1.5">
                          Base de cumplimiento normativo SUGEF 2-10
                        </span>
                      </div>

                    </div>
                  </div>
                )}

                {/* PROJECT 3 VIEW: Forecasting */}
                {selectedProject.id === 'forecasting-ventas' && (
                  <div className="space-y-4 font-mono text-xs text-slate-300">
                    <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-4">
                      <div className="flex justify-between items-center">
                        <span className="text-xs font-bold text-white uppercase tracking-wider">
                          Modelo Predictivo: Simulación de Ventas Futuras
                        </span>
                        <span className="text-[10px] text-slate-400 bg-brand-blue/10 px-2 py-0.5 rounded border border-brand-blue/20">
                          Algoritmo Integrado
                        </span>
                      </div>
                      
                      <div className="space-y-2">
                        <div className="flex justify-between border-b border-slate-800/50 py-1">
                          <span className="text-slate-400">Ciclo Histórico Evaluado</span>
                          <span className="text-white">60 meses</span>
                        </div>
                        <div className="flex justify-between border-b border-slate-800/50 py-1">
                          <span className="text-slate-400">Nivel de Confianza Comercial</span>
                          <span className="text-brand-green font-bold">95.0%</span>
                        </div>
                        <div className="flex justify-between border-b border-slate-800/50 py-1">
                          <span className="text-slate-400">Margen de Error Máximo</span>
                          <span className="text-slate-300 font-semibold">&lt; 4.2%</span>
                        </div>
                      </div>

                      <div className="h-28 flex items-end justify-between gap-2.5 pt-4">
                        <div className="w-full flex flex-col items-center gap-1.5">
                          <div className="w-full bg-slate-800 rounded-t h-16 relative">
                            <div className="absolute inset-x-0 bottom-0 bg-brand-blue/30 h-[92%] rounded-t" />
                          </div>
                          <span className="text-[10px] text-slate-500">Histórico</span>
                        </div>
                        <div className="w-full flex flex-col items-center gap-1.5">
                          <div className="w-full bg-slate-800 rounded-t h-20 relative">
                            <div className="absolute inset-x-0 bottom-0 bg-brand-green/30 h-[95%] rounded-t" />
                          </div>
                          <span className="text-[10px] text-slate-400">Fitted (Ciclos)</span>
                        </div>
                        <div className="w-full flex flex-col items-center gap-1.5">
                          <div className="w-full bg-slate-800 rounded-t h-24 relative border-t-2 border-dashed border-brand-green">
                            <div className="absolute inset-x-0 bottom-0 bg-brand-green/40 h-[100%] rounded-t" />
                          </div>
                          <span className="text-[10px] text-brand-green font-bold">Pronóstico</span>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* PROJECT 4 VIEW: Distribución Suzuki */}
                {selectedProject.id === 'distribucion-mercado' && (
                  <div className="space-y-4 font-mono text-xs text-slate-300">
                    <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-4">
                      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2 border-b border-slate-800 pb-2">
                        <div>
                          <span className="text-xs font-bold text-white uppercase block">
                            Suzuki GIXXER-150 / 300K+ Registros
                          </span>
                          <span className="text-[10px] text-slate-500">Segmentación de Mercado de Motocicletas</span>
                        </div>
                        <div className="flex gap-1">
                          <button 
                            onClick={() => setSuzukiModel('GIXXER-150')}
                            className={`px-2 py-0.5 rounded text-[10px] border ${suzukiModel === 'GIXXER-150' ? 'bg-brand-blue/10 border-brand-blue/30 text-white' : 'border-slate-800 text-slate-500'}`}
                          >
                            GIXXER-150
                          </button>
                          <button 
                            onClick={() => setSuzukiModel('OTRO')}
                            className={`px-2 py-0.5 rounded text-[10px] border ${suzukiModel === 'OTRO' ? 'bg-brand-blue/10 border-brand-blue/30 text-white' : 'border-slate-800 text-slate-500'}`}
                          >
                            Otros Modelos
                          </button>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4 text-[11px]">
                        <div className="space-y-1.5">
                          <span className="text-slate-500 block uppercase tracking-wider text-[9px]">Ubicaciones Geográficas</span>
                          <div className="flex justify-between">
                            <span className="text-slate-400">Central (Gran Área Metropolitana)</span>
                            <span className="text-white font-bold">75%</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-400">Atlántico / Limón</span>
                            <span className="text-white">12%</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-400">Chorotega / Guanacaste</span>
                            <span className="text-white">10%</span>
                          </div>
                        </div>

                        <div className="space-y-1.5">
                          <span className="text-slate-500 block uppercase tracking-wider text-[9px]">Demografía Compradora</span>
                          <div className="flex justify-between">
                            <span className="text-slate-400">Rango Edad Principal (22-27 años)</span>
                            <span className="text-white font-bold">42%</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-400">Rango Edad Secundario (28-32 años)</span>
                            <span className="text-white">31%</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-400">Segmento de Género Masculino</span>
                            <span className="text-white">87%</span>
                          </div>
                        </div>
                      </div>

                      <div className="p-3 bg-slate-950 rounded-lg border border-slate-900 flex items-center justify-between text-[10px]">
                        <span className="text-slate-400">Origen Comercial Principal:</span>
                        <span className="text-white font-bold uppercase text-brand-green bg-brand-green/5 px-2 py-0.5 rounded border border-brand-green/20">
                          VIRTUAL / REDES SOCIALES (42%)
                        </span>
                      </div>
                    </div>
                  </div>
                )}

                {/* PROJECT 5 VIEW: Análisis de Competencia */}
                {selectedProject.id === 'analisis-competencia' && (
                  <div className="space-y-4 font-mono text-xs text-slate-300">
                    <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-3">
                      <span className="text-xs font-bold text-white uppercase tracking-wider block border-b border-slate-800 pb-2">
                        Cuota de Mercado de Motocicletas (Scooters & Sport)
                      </span>
                      
                      <div className="space-y-2.5 pt-1 text-[11px]">
                        <div>
                          <div className="flex justify-between text-[10px] text-slate-400 mb-1">
                            <span>CATEGORÍA SPORT - NUESTRAS MARCAS</span>
                            <span className="text-white font-bold">38.2% de Market Share</span>
                          </div>
                          <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-850">
                            <div className="bg-brand-blue h-full rounded-full" style={{ width: '38.2%' }} />
                          </div>
                        </div>

                        <div>
                          <div className="flex justify-between text-[10px] text-slate-400 mb-1">
                            <span>CATEGORÍA SCOOTER - NUESTRAS MARCAS</span>
                            <span className="text-white font-bold">33.2% de Market Share</span>
                          </div>
                          <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-850">
                            <div className="bg-brand-green h-full rounded-full" style={{ width: '33.2%' }} />
                          </div>
                        </div>

                        <div>
                          <div className="flex justify-between text-[10px] text-slate-400 mb-1">
                            <span>COMPETENCIA DIRECTA (Grupo A / Marcas B)</span>
                            <span className="text-white font-bold">28.6% de Market Share</span>
                          </div>
                          <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-850">
                            <div className="bg-slate-700 h-full rounded-full" style={{ width: '28.6%' }} />
                          </div>
                        </div>
                      </div>

                      <p className="text-[10px] text-slate-500 italic pt-2">
                        *Análisis cruzado de bases de datos externas de aduanas e importaciones con comparativas interanuales de USD.
                      </p>
                    </div>
                  </div>
                )}

              </div>

              {/* Performance Impact Metrics Grid */}
              <div className="space-y-3">
                <h4 className="text-xs font-mono uppercase tracking-widest text-slate-500">
                  Impacto Cuantificable del Proyecto
                </h4>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {selectedProject.metrics.map(metric => (
                    <div key={metric.label} className="p-4 rounded-xl bg-slate-900/30 border border-slate-900 flex flex-col justify-between">
                      <span className="text-[10px] font-mono text-slate-500 uppercase tracking-wider mb-2 leading-tight">
                        {metric.label}
                      </span>
                      <span className="text-base font-bold text-white font-display flex items-center gap-1">
                        {metric.value}
                        {metric.improved && (
                          <span className="text-[10px] text-brand-green">✓</span>
                        )}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          </motion.div>
        </div>

      </section>
    </div>
  );
}
