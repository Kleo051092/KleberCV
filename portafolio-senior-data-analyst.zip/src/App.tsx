import { useState, useEffect } from 'react';
import Hero from './components/Hero';
import Skills from './components/Skills';
import Projects from './components/Projects';
import ExperiencePage from './components/ExperiencePage';
import EducationPage from './components/EducationPage';
import ContactFooter from './components/ContactFooter';
import DetailedPortfolio from './components/DetailedPortfolio';
import { 
  Database, 
  TrendingUp, 
  Cpu, 
  FolderGit2, 
  User, 
  Briefcase, 
  GraduationCap, 
  Menu, 
  X 
} from 'lucide-react';

export default function App() {
  const [isOpen, setIsOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState<'profile' | 'projects' | 'experience' | 'education'>(() => {
    const hash = window.location.hash;
    if (hash === '#/proyectos') return 'projects';
    if (hash === '#/experiencia') return 'experience';
    if (hash === '#/estudios') return 'education';
    return 'profile';
  });

  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash;
      if (hash === '#/proyectos') {
        setCurrentPage('projects');
      } else if (hash === '#/experiencia') {
        setCurrentPage('experience');
      } else if (hash === '#/estudios') {
        setCurrentPage('education');
      } else {
        setCurrentPage('profile');
      }
      window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const handleNavigation = (target: 'profile' | 'projects' | 'experience' | 'education') => {
    setIsOpen(false);
    if (currentPage !== target) {
      setCurrentPage(target);
      if (target === 'projects') {
        window.location.hash = '#/proyectos';
      } else if (target === 'experience') {
        window.location.hash = '#/experiencia';
      } else if (target === 'education') {
        window.location.hash = '#/estudios';
      } else {
        window.location.hash = '#/';
      }
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-brand-blue/30 selection:text-white">
      
      {/* Top Sticky Header */}
      <header className="w-full bg-slate-950/80 backdrop-blur-md sticky top-0 z-50 border-b border-slate-900/80">
        <div className="max-w-6xl mx-auto px-4 md:px-8 py-4 flex items-center justify-between gap-4">
          <button 
            onClick={() => handleNavigation('profile')}
            className="flex items-center gap-2.5 text-left hover:opacity-90 transition-opacity"
          >
            <div className="w-9 h-9 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-center text-brand-green shrink-0">
              <Cpu className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <span className="font-display font-bold text-sm tracking-wider text-white uppercase block">Kleber Villalobos</span>
              <span className="text-[10px] font-mono text-slate-500 uppercase tracking-widest block max-w-xs sm:max-w-none truncate">Analista de Datos  |  Analista de Riesgos</span>
            </div>
          </button>

          {/* Desktop Navigation (MD and Above) */}
          <nav className="hidden md:flex items-center gap-1 bg-slate-900/40 border border-slate-900 p-1 rounded-xl text-xs font-mono">
            <button
              onClick={() => handleNavigation('profile')}
              className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 ${
                currentPage === 'profile'
                  ? 'bg-brand-green/15 text-brand-green border border-brand-green/20 font-semibold'
                  : 'text-slate-400 hover:text-white border border-transparent'
              }`}
            >
              <User className="w-3.5 h-3.5" />
              <span>Mi perfil</span>
            </button>
            <button
              onClick={() => handleNavigation('projects')}
              className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 ${
                currentPage === 'projects'
                  ? 'bg-brand-green/15 text-brand-green border border-brand-green/20 font-semibold'
                  : 'text-slate-400 hover:text-white border border-transparent'
              }`}
            >
              <FolderGit2 className="w-3.5 h-3.5" />
              <span>Portafolio de Proyectos</span>
            </button>
            <button
              onClick={() => handleNavigation('experience')}
              className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 ${
                currentPage === 'experience'
                  ? 'bg-brand-green/15 text-brand-green border border-brand-green/20 font-semibold'
                  : 'text-slate-400 hover:text-white border border-transparent'
              }`}
            >
              <Briefcase className="w-3.5 h-3.5" />
              <span>Experiencia Profesional</span>
            </button>
            <button
              onClick={() => handleNavigation('education')}
              className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 ${
                currentPage === 'education'
                  ? 'bg-brand-green/15 text-brand-green border border-brand-green/20 font-semibold'
                  : 'text-slate-400 hover:text-white border border-transparent'
              }`}
            >
              <GraduationCap className="w-3.5 h-3.5" />
              <span>Estudios</span>
            </button>
          </nav>

          {/* Mobile Hamburger Toggle Button */}
          <div className="flex md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="p-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-400 hover:text-white transition-all"
              aria-label="Toggle menu"
            >
              {isOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Dropdown Menu */}
        {isOpen && (
          <div className="md:hidden border-b border-slate-900 bg-slate-950/95 backdrop-blur-lg absolute top-full left-0 w-full z-40 p-4 space-y-1.5 flex flex-col shadow-2xl">
            <button
              onClick={() => handleNavigation('profile')}
              className={`w-full text-left px-4 py-3 rounded-xl transition-all flex items-center gap-3 text-xs font-mono ${
                currentPage === 'profile'
                  ? 'bg-brand-green/10 text-brand-green font-semibold'
                  : 'text-slate-300 hover:bg-slate-900/50'
              }`}
            >
              <User className="w-4 h-4 text-brand-green" />
              <span>Mi perfil</span>
            </button>

            <button
              onClick={() => handleNavigation('projects')}
              className={`w-full text-left px-4 py-3 rounded-xl transition-all flex items-center gap-3 text-xs font-mono ${
                currentPage === 'projects'
                  ? 'bg-brand-green/10 text-brand-green font-semibold'
                  : 'text-slate-300 hover:bg-slate-900/50'
              }`}
            >
              <FolderGit2 className="w-4 h-4 text-brand-green" />
              <span>Portafolio de Proyectos</span>
            </button>

            <button
              onClick={() => handleNavigation('experience')}
              className={`w-full text-left px-4 py-3 rounded-xl transition-all flex items-center gap-3 text-xs font-mono ${
                currentPage === 'experience'
                  ? 'bg-brand-green/10 text-brand-green font-semibold'
                  : 'text-slate-300 hover:bg-slate-900/50'
              }`}
            >
              <Briefcase className="w-4 h-4 text-brand-green" />
              <span>Experiencia Profesional</span>
            </button>

            <button
              onClick={() => handleNavigation('education')}
              className={`w-full text-left px-4 py-3 rounded-xl transition-all flex items-center gap-3 text-xs font-mono ${
                currentPage === 'education'
                  ? 'bg-brand-green/10 text-brand-green font-semibold'
                  : 'text-slate-300 hover:bg-slate-900/50'
              }`}
            >
              <GraduationCap className="w-4 h-4 text-brand-green" />
              <span>Estudios</span>
            </button>
          </div>
        )}
      </header>

      {/* Main Content Sections with Page Transitions */}
      <main className="flex-grow">
        {currentPage === 'profile' ? (
          <div>
            <Hero />
            
            {/* Quick Navigation Bento Box */}
            <div className="max-w-6xl mx-auto px-4 md:px-8 py-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                
                {/* Promo Card: Second Web (Projects) */}
                <div className="p-6 rounded-2xl bg-slate-900/35 border border-slate-900 hover:border-slate-800/80 transition-all flex flex-col justify-between gap-5 relative overflow-hidden group">
                  <div className="absolute top-0 right-0 w-16 h-16 bg-gradient-to-bl from-brand-green/5 to-transparent pointer-events-none" />
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded bg-brand-green/10 text-brand-green font-mono text-[9px] uppercase tracking-wider font-semibold">2da Web</span>
                    </div>
                    <h4 className="text-base font-bold text-white font-display">Portafolio de Proyectos</h4>
                    <p className="text-xs text-slate-400 leading-relaxed">Dashboards técnicos e interactivos con métricas de negocio reales presentadas ante gerencia.</p>
                  </div>
                  <button
                    onClick={() => handleNavigation('projects')}
                    className="w-full py-2 rounded-xl bg-slate-950 border border-slate-800 hover:border-slate-700 text-slate-300 hover:text-white font-mono font-bold text-[11px] transition-all flex items-center justify-center gap-2"
                  >
                    <span>Ver Dashboards</span>
                    <FolderGit2 className="w-3.5 h-3.5 text-brand-green" />
                  </button>
                </div>

                {/* Promo Card: Third Web (Experience) */}
                <div className="p-6 rounded-2xl bg-slate-900/35 border border-slate-900 hover:border-slate-800/80 transition-all flex flex-col justify-between gap-5 relative overflow-hidden group">
                  <div className="absolute top-0 right-0 w-16 h-16 bg-gradient-to-bl from-brand-blue/5 to-transparent pointer-events-none" />
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded bg-brand-blue/10 text-brand-blue font-mono text-[9px] uppercase tracking-wider font-semibold">3ra Web</span>
                    </div>
                    <h4 className="text-base font-bold text-white font-display">Experiencia Profesional</h4>
                    <p className="text-xs text-slate-400 leading-relaxed">Trayectoria detallada con impactos de negocio cuantificables en riesgo, finanzas y analítica.</p>
                  </div>
                  <button
                    onClick={() => handleNavigation('experience')}
                    className="w-full py-2 rounded-xl bg-slate-950 border border-slate-800 hover:border-slate-700 text-slate-300 hover:text-white font-mono font-bold text-[11px] transition-all flex items-center justify-center gap-2"
                  >
                    <span>Ver Trayectoria</span>
                    <Briefcase className="w-3.5 h-3.5 text-brand-blue" />
                  </button>
                </div>

                {/* Promo Card: Fourth Web (Education) */}
                <div className="p-6 rounded-2xl bg-slate-900/35 border border-slate-900 hover:border-slate-800/80 transition-all flex flex-col justify-between gap-5 relative overflow-hidden group">
                  <div className="absolute top-0 right-0 w-16 h-16 bg-gradient-to-bl from-brand-green/5 to-transparent pointer-events-none" />
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded bg-brand-green/10 text-brand-green font-mono text-[9px] uppercase tracking-wider font-semibold">4ta Web</span>
                    </div>
                    <h4 className="text-base font-bold text-white font-display">Estudios y Certificaciones</h4>
                    <p className="text-xs text-slate-400 leading-relaxed">Formación académica sólida en Economía, especialización en IA y certificaciones técnicas.</p>
                  </div>
                  <button
                    onClick={() => handleNavigation('education')}
                    className="w-full py-2 rounded-xl bg-slate-950 border border-slate-800 hover:border-slate-700 text-slate-300 hover:text-white font-mono font-bold text-[11px] transition-all flex items-center justify-center gap-2"
                  >
                    <span>Ver Estudios</span>
                    <GraduationCap className="w-3.5 h-3.5 text-brand-green" />
                  </button>
                </div>

              </div>
            </div>

            <Skills />
            
            <Projects />
          </div>
        ) : currentPage === 'projects' ? (
          <DetailedPortfolio onBackToProfile={() => handleNavigation('profile')} />
        ) : currentPage === 'experience' ? (
          <ExperiencePage onBackToProfile={() => handleNavigation('profile')} />
        ) : (
          <EducationPage onBackToProfile={() => handleNavigation('profile')} />
        )}
      </main>

      {/* Contact and Footer */}
      <ContactFooter />
    </div>
  );
}
